--[[ =========================================================
     LAST STAND HUD — Main Client
     ESX Bootstrap, Spielerdaten, Geld/Job/Status-Sync
     ========================================================= ]]
ESX = exports['es_extended']:getSharedObject()

local PlayerData   = {}
local playerLoaded = false

local function accountValue(name)
    for _, acc in ipairs(PlayerData.accounts or {}) do
        if acc.name == name then return acc.money or 0 end
    end
    return 0
end

local function pushMoney()
    local xPlayer = ESX.GetPlayerData()
    local accounts = (xPlayer and xPlayer.accounts) or PlayerData.accounts or {}
    local function accValue(name)
        for _, acc in ipairs(accounts) do
            if acc.name == name then return acc.money or 0 end
        end
        return 0
    end
    LastStandHUD.send('setMoney', {
        cash  = accValue('money'),
        bank  = accValue('bank'),
        black = accValue('black_money'),
    })
end

local function pushCash()
    local xPlayer = ESX.GetPlayerData()
    local accounts = (xPlayer and xPlayer.accounts) or PlayerData.accounts or {}
    for _, acc in ipairs(accounts) do
        if acc.name == 'money' then
            LastStandHUD.send('setCash', { value = acc.money or 0 })
            return
        end
    end
    LastStandHUD.send('setCash', { value = 0 })
end

local function pushBank()
    local xPlayer = ESX.GetPlayerData()
    local accounts = (xPlayer and xPlayer.accounts) or PlayerData.accounts or {}
    for _, acc in ipairs(accounts) do
        if acc.name == 'bank' then
            LastStandHUD.send('setBank', { value = acc.money or 0 })
            return
        end
    end
    LastStandHUD.send('setBank', { value = 0 })
end

local function pushBlack()
    local xPlayer = ESX.GetPlayerData()
    local accounts = (xPlayer and xPlayer.accounts) or PlayerData.accounts or {}
    for _, acc in ipairs(accounts) do
        if acc.name == 'black_money' then
            LastStandHUD.send('setBlack', { value = acc.money or 0 })
            return
        end
    end
    LastStandHUD.send('setBlack', { value = 0 })
end

local function pushJob()
    local xPlayer = ESX.GetPlayerData()
    local job = (xPlayer and xPlayer.job) or PlayerData.job or {}
    local gradeLabel = ''
    if job.grade_label then
        gradeLabel = job.grade_label
    elseif job.grade then
        gradeLabel = tostring(job.grade)
    end
    LastStandHUD.send('setJob', {
        name  = job.label or job.name or 'Arbeitslos',
        grade = gradeLabel,
    })
end

local function pushId()
    local serverId = GetPlayerServerId(PlayerId())
    if not serverId or serverId == 0 then
        -- Fallback: Versuche ESX PlayerData zu verwenden
        local xPlayer = ESX.GetPlayerData()
        if xPlayer and xPlayer.id then
            serverId = xPlayer.id
        end
    end
    LastStandHUD.send('setId', { id = serverId or 0 })
end

local function onLoaded(xPlayer)
    PlayerData   = xPlayer or ESX.GetPlayerData() or {}
    playerLoaded = true

    LastStandHUD.invalidate()
    pushId()
    pushMoney()
    pushJob()
    LastStandHUD.send('setStatus', { hunger = 100, thirst = 100 })
    LastStandHUD.state.ready = true

    TriggerServerEvent('lastStandHud:requestState')
end

CreateThread(function()
    local pd = ESX.GetPlayerData()
    local waited = 0
    while (not pd or not pd.job) and waited < 20000 do
        Wait(250); waited = waited + 250
        pd = ESX.GetPlayerData()
    end
    if pd and pd.job then onLoaded(pd) end
end)

RegisterNetEvent('esx:playerLoaded', function(xPlayer)
    onLoaded(xPlayer)
end)

RegisterNetEvent('esx:onPlayerLogout', function()
    playerLoaded = false
    LastStandHUD.state.ready = false
end)

RegisterNetEvent('esx:setJob', function(job)
    PlayerData.job = job
    if playerLoaded then pushJob() end
end)

RegisterNetEvent('esx:setAccountMoney', function(account)
    for i, acc in ipairs(PlayerData.accounts or {}) do
        if acc.name == account.name then PlayerData.accounts[i] = account end
    end
    if playerLoaded then
        -- Update individual money containers independently
        if account.name == 'money' then
            pushCash()
        elseif account.name == 'bank' then
            pushBank()
        elseif account.name == 'black_money' then
            pushBlack()
        else
            pushMoney()
        end
    end
end)

-- Status-Tick
local lastHunger, lastThirst = -1, -1

local function readStatus()
    if not Config.UseESXStatus then return nil, nil end
    local hunger, thirst = nil, nil
    TriggerEvent('esx_status:getStatus', 'hunger', function(s)
        if s and s.val then hunger = math.floor(s.val / 10000) end
    end)
    TriggerEvent('esx_status:getStatus', 'thirst', function(s)
        if s and s.val then thirst = math.floor(s.val / 10000) end
    end)
    return hunger, thirst
end

CreateThread(function()
    while true do
        Wait(Config.UpdateRate)
        if playerLoaded then
            local h, t = readStatus()
            if h and t and (h ~= lastHunger or t ~= lastThirst) then
                lastHunger, lastThirst = h, t
                LastStandHUD.send('setStatus', { hunger = h, thirst = t })
            end
            pushId()
        end
    end
end)

-- Auto-Hide (Tod / Pausemenü)
CreateThread(function()
    while true do
        Wait(Config.VisibilityCheckRate)
        local ped  = PlayerPedId()
        local hide = false
        if Config.AutoHideOnDeath     and IsEntityDead(ped)   then hide = true end
        if Config.AutoHideOnPauseMenu and IsPauseMenuActive() then hide = true end

        local want = LastStandHUD.state.master and not hide
        if LastStandHUD.state.visibleNow ~= want then
            LastStandHUD.state.visibleNow = want
            SendNUIMessage({ action = 'setMaster', enabled = want })
        end
    end
end)
