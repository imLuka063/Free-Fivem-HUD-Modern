--[[ =========================================================
     LAST STAND HUD — Client Exports & Network Events
     ========================================================= ]]

-- Network Events (vom Server)
RegisterNetEvent('lastStandHud:notify', function(p)
    p = p or {}
    SendNUIMessage({
        action   = 'notify',
        type     = p.type,
        title    = p.title,
        message  = p.message,
        color    = p.color,
        duration = p.duration,
    })
end)

RegisterNetEvent('lastStandHud:clearNotifications', function()
    SendNUIMessage({ action = 'clearNotifications' })
end)

RegisterNetEvent('lastStandHud:announce', function(p)
    p = p or {}
    SendNUIMessage({
        action   = 'showAnnouncement',
        title    = p.title    or 'Ankündigung',
        message  = p.message  or '',
        icon     = p.icon     or '!',
        duration = p.duration or 8000,
    })
end)

RegisterNetEvent('lastStandHud:announceHide', function()
    SendNUIMessage({ action = 'hideAnnouncement' })
end)

RegisterNetEvent('lastStandHud:help', function(p)
    p = p or {}
    SendNUIMessage({ action = 'showHelp', key = p.key or 'E', text = p.text or '' })
end)

RegisterNetEvent('lastStandHud:helpHide', function()
    SendNUIMessage({ action = 'hideHelp' })
end)

RegisterNetEvent('lastStandHud:progressStart', function(p)
    p = p or {}
    SendNUIMessage({
        action      = 'progressStart',
        label       = p.label       or 'Arbeiten...',
        duration    = p.duration    or 3000,
        cancelKey   = p.cancelKey   or 'X',
        cancellable = p.cancellable ~= false,
    })
end)

RegisterNetEvent('lastStandHud:loadState', function(state)
    state = state or {}
    if type(state.layout) == 'table' and next(state.layout) then
        -- Remove money elements from saved layout to use CSS positioning
        state.layout['money-cash'] = nil
        state.layout['money-bank'] = nil
        state.layout['money-black'] = nil
        
        -- Only send layout if there are still elements left
        if next(state.layout) then
            SendNUIMessage({ action = 'loadLayout', layout = state.layout })
        end
    end
    if type(state.elements) == 'table' then
        for id, enabled in pairs(state.elements) do
            LastStandHUD.state.elements[id] = enabled
            SendNUIMessage({ action = 'toggleElement', id = id, enabled = enabled })
        end
    end
    if state.master ~= nil then
        LastStandHUD.state.master = not not state.master
        SendNUIMessage({ action = 'setMaster', enabled = LastStandHUD.state.master })
    end
    if state.kino ~= nil then
        LastStandHUD.state.kino = not not state.kino
        SendNUIMessage({ action = 'setKino', enabled = LastStandHUD.state.kino })
    end
end)

-- Public Exports
exports('ShowNotification', function(message, notifyType, title, duration, color)
    SendNUIMessage({
        action   = 'notify',
        type     = notifyType or 'info',
        title    = title,
        message  = message,
        duration = duration,
        color    = color,
    })
end)

exports('ShowAdvancedNotification', function(title, subject, message, color, icon)
    SendNUIMessage({
        action  = 'notify',
        type    = 'info',
        title   = title or subject,
        message = message,
        color   = color,
        icon    = icon,
    })
end)

exports('ClearNotifications', function()
    SendNUIMessage({ action = 'clearNotifications' })
end)

exports('ShowHelpNotification', function(key, text)
    SendNUIMessage({ action = 'showHelp', key = key or 'E', text = text or '' })
end)

exports('HideHelpNotification', function()
    SendNUIMessage({ action = 'hideHelp' })
end)

exports('ShowAnnouncement', function(title, message, icon, duration)
    SendNUIMessage({
        action   = 'showAnnouncement',
        title    = title   or 'Ankündigung',
        message  = message or '',
        icon     = icon    or '!',
        duration = duration or 8000,
    })
end)

exports('HideAnnouncement', function()
    SendNUIMessage({ action = 'hideAnnouncement' })
end)

exports('StartProgress', function(label, duration, cancelKey, cancellable)
    SendNUIMessage({
        action      = 'progressStart',
        label       = label    or 'Arbeiten...',
        duration    = duration or 3000,
        cancelKey   = cancelKey or 'X',
        cancellable = cancellable ~= false,
    })
end)

exports('UpdateProgress', function(percent)
    SendNUIMessage({ action = 'progressUpdate', percent = tonumber(percent) or 0 })
end)

exports('FinishProgress', function()
    SendNUIMessage({ action = 'progressFinish' })
end)

exports('CancelProgress', function()
    SendNUIMessage({ action = 'progressCancel' })
end)

exports('SetMaster', function(enabled)
    LastStandHUD.state.master = not not enabled
    SendNUIMessage({ action = 'setMaster', enabled = LastStandHUD.state.master })
end)

exports('SetKino', function(enabled)
    LastStandHUD.state.kino = not not enabled
    SendNUIMessage({ action = 'setKino', enabled = LastStandHUD.state.kino })
end)

exports('ToggleElement', function(id, enabled)
    if not id then return end
    LastStandHUD.state.elements[id] = not not enabled
    SendNUIMessage({ action = 'toggleElement', id = id, enabled = enabled })
end)

exports('OpenEditor', function()
    LastStandHUD.setFocus(true)
    SendNUIMessage({ action = 'openEditor' })
end)

exports('CloseEditor', function()
    LastStandHUD.setFocus(false)
    SendNUIMessage({ action = 'closeEditor' })
end)

exports('IsHudVisible', function()
    return LastStandHUD.state.visibleNow
end)
