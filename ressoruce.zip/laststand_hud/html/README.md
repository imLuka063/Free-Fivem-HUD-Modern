# LAST STAND — FiveM HUD

Pure HTML / CSS / JavaScript NUI HUD. No build step.

## Files

```
public/hud/
├── index.html
├── css/
│   ├── hud.css         # design tokens, layout, animations
│   ├── components.css  # every HUD widget
│   └── editor.css      # /hud customization menu
└── js/
    ├── utils.js          # LS.post(), color resolver
    ├── notifications.js  # LS.Notifications
    ├── announcement.js   # LS.Announcement
    ├── help.js           # LS.Help
    ├── progress.js       # LS.Progress
    ├── status.js         # LS.Status, Money, ID, Voice, Job, Clock, Location
    ├── editor.js         # LS.Editor (drag, snap, save)
    ├── events.js         # NUI message bridge
    └── main.js           # bootstrap + browser preview demo
```

## Preview

Open `/hud/` in a browser. Press **H** to toggle the customization menu.

## FiveM integration

In your `fxmanifest.lua`:

```lua
ui_page 'public/hud/index.html'
files {
  'public/hud/index.html',
  'public/hud/css/*.css',
  'public/hud/js/*.js',
}
```

(Or copy the `public/hud/` folder into your resource as `html/`.)

## Backend events (Lua)

Every event uses `SendNUIMessage({ action = '...' , ... })`.

```lua
-- Notifications
SendNUIMessage({ action = 'notify', type = 'success', title = 'Money', message = 'Received $500' })
SendNUIMessage({ action = 'notify', type = 'error',   message = 'Inventory full' })
SendNUIMessage({ action = 'notify', color = '#ff7a00', title = 'Custom', message = 'Hex color' })
SendNUIMessage({ action = 'notify', type = 'teamchat', message = 'Suspect on Vinewood' })

-- Announcement
SendNUIMessage({ action = 'showAnnouncement', title = 'Restart', message = '10 min', icon = '!', duration = 8000 })
SendNUIMessage({ action = 'hideAnnouncement' })

-- Help
SendNUIMessage({ action = 'showHelp', key = 'E', text = 'Open Inventory' })
SendNUIMessage({ action = 'hideHelp' })

-- Progress
SendNUIMessage({ action = 'progressStart', label = 'Lockpicking', duration = 5000, cancelKey = 'X' })
SendNUIMessage({ action = 'progressCancel' })

-- Money / ID / Status
SendNUIMessage({ action = 'setMoney',  cash = 1450, bank = 28000, black = 750 })
SendNUIMessage({ action = 'setId',     id = 42 })
SendNUIMessage({ action = 'setStatus', hunger = 80, thirst = 60 })

-- Voice
SendNUIMessage({ action = 'setVoice', label = 'Whisper', tier = 0, total = 3 })

-- Job / Time / Location
SendNUIMessage({ action = 'setJob',      name = 'Police', grade = 3 })
SendNUIMessage({ action = 'setTime',     time = '21:34', date = '08.05.2026' })
SendNUIMessage({ action = 'setLocation', street = 'Vinewood Blvd', area = 'Vinewood' })

-- HUD editor & toggles
SendNUIMessage({ action = 'openEditor' })
SendNUIMessage({ action = 'toggleElement', id = 'minimap', enabled = false })
SendNUIMessage({ action = 'setKino',   enabled = true })
SendNUIMessage({ action = 'setMaster', enabled = true })
SendNUIMessage({ action = 'loadLayout', layout = savedLayout })
```

### `/hud` command

```lua
RegisterCommand('hud', function()
  SetNuiFocus(true, true)
  SendNUIMessage({ action = 'openEditor' })
end)

RegisterNUICallback('editorClose', function(_, cb)
  SetNuiFocus(false, false); cb('ok')
end)

RegisterNUICallback('saveLayout', function(data, cb)
  -- persist data.layout to your DB / KVP
  cb('ok')
end)

RegisterNUICallback('progressCancel',  function(_, cb) cb('ok') end)
RegisterNUICallback('toggleElement',   function(_, cb) cb('ok') end)
RegisterNUICallback('toggleKino',      function(_, cb) cb('ok') end)
RegisterNUICallback('toggleMaster',    function(_, cb) cb('ok') end)
RegisterNUICallback('resetLayout',     function(_, cb) cb('ok') end)
RegisterNUICallback('editorOpen',      function(_, cb) cb('ok') end)
```

## Theme

All colors live in `:root` inside `css/hud.css`. Edit `--ls-red` to recolor the entire HUD.
